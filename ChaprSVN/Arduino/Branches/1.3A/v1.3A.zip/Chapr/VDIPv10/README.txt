This library implements the VDIP interface which consists of a "manual"
implmentation of the SPI interface that the VDIP uses.  There are two
objects 
