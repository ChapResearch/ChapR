//
// watchdog.h
//
//	Simple declaration of the watchdog functions.
//

#ifndef WATCHDOG_H
#define WATCHDOG_H

void watchdogFeed();
void watchdogOn();
void watchdogOff();
void watchdogBite();

#endif
